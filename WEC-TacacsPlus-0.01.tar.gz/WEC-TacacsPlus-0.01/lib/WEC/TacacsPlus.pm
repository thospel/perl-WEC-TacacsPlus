package WEC::TacacsPlus;
use 5.006001;
our $VERSION = '0.01';


1;
__END__
# Below is stub documentation for your module. You'd better edit it!

=head1 NAME

Net::TacacsPlus - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Net::TacacsPlus;
  blah blah blah

=head1 ABSTRACT

  This should be the abstract for Net::TacacsPlus.
  The abstract is used when making PPD (Perl Package Description) files.
  If you don't want an ABSTRACT you should also edit Makefile.PL to
  remove the ABSTRACT_FROM option.

=head1 DESCRIPTION

Stub documentation for Net::TacacsPlus, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.



=head1 SEE ALSO

Mention other useful documentation such as the documentation of
related modules or operating system documentation (such as man pages
in UNIX), or any relevant external documentation such as RFCs or
standards.

If you have a mailing list set up for your module, mention it here.

If you have a web site set up for your module, mention it here.

=head1 AUTHOR

Ton Hospel, E<lt>WEC::TacacsPlus@ton.iguana.beE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright 2003 by Ton Hospel

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself. 

=cut
